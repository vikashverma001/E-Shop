from django.shortcuts import render
from django.views import View
from store.models.product import Product
import razorpay
    
class Pay(View):
    def get(self,request):
        ids=list(request.session.get('cart').keys())
        products=Product.get_products_by_id(ids)
        # print(products)
        return render(request,'pay.html',{'products': products}) 

