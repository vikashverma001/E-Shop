# from django.shortcuts import render, redirect
# from django.views import View
# 



# class Profile(View):
#     def get(self,request):
#         customer=Customer.objects.get(email=request.user.email)
#         context= {
#             'customer':customer
#         }
#         return render(request,'profile.html',context)
    
from django.shortcuts import render, redirect
from store.models import Customer
from django.views import View


class Profile(View):
    def get(self, request):
        # first_name=request.POST.get('firstname')
        # last_name=request.POST.get('lastnamename')

        # email=request.POST.get('email')
        # phone=request.POST.get('phone')
        # print(first_name,last_name,email,phone)
        return render(request, 'profile.html')

